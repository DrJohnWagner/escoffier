import React from "react";
// --- THIS IS THE FIX ---
// Import the single, canonical ContentBlock type from your auto-generated file.
import { ContentBlock } from "@/types/generated.ts/chapter-schema";

// The local interfaces are no longer needed.

// --- The exported props type now uses the imported ContentBlock type ---
export interface ContentBlockListProps {
	items?: ContentBlock[];
	isOrdered?: boolean;
	title?: string;
}

const ContentBlockList: React.FC<ContentBlockListProps> = ({
	items,
	isOrdered = false,
	title,
}) => {
	if (!items || items.length === 0) return null;

	const ListTag = isOrdered ? "ol" : "ul";
	const NestedListTag = isOrdered ? "ol" : "ul";
	const keyTracker: { [key: string]: number } = {};

	return (
		<div
			className={`content-block-list-container space-y-4 ${title?.toLowerCase()}`}
		>
			{title && (
				<h3 className="text-xl font-semibold text-gray-800 border-b pb-2">
					{title}
				</h3>
			)}
			<ListTag
				className={`${
					isOrdered ? "list-decimal" : "list-disc"
				} list-inside space-y-2 text-gray-700`}
			>
				{items.map((item) => {
					// This logic is now perfectly type-safe against the generated type.
					if (typeof item === "string") {
						keyTracker[item] = (keyTracker[item] || 0) + 1;
						const key = `${item}-${keyTracker[item]}`;
						return <li key={key}>{item}</li>;
					}

					if (typeof item === "object" && item !== null) {
						const blockTitle = Object.keys(item)[0];
						const blockDetails = item[blockTitle];
						const nestedKeyTracker: { [key: string]: number } = {};

						return (
							<li key={blockTitle} className="list-none mt-2">
								<h4 className="font-semibold text-gray-700">{blockTitle}</h4>
								<NestedListTag
									className={`${
										isOrdered ? "list-decimal" : "list-disc"
									} list-inside mt-2 pl-5 space-y-1`}
								>
									{blockDetails.map((detail) => {
										nestedKeyTracker[detail] =
											(nestedKeyTracker[detail] || 0) + 1;
										const nestedKey = `${detail}-${nestedKeyTracker[detail]}`;
										return <li key={nestedKey}>{detail}</li>;
									})}
								</NestedListTag>
							</li>
						);
					}
					return null;
				})}
			</ListTag>
		</div>
	);
};

export default ContentBlockList;
