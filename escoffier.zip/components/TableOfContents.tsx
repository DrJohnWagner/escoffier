import Link from "next/link";
import { PartEntry, ChapterEntry } from "@/types/generated.ts/cookbook-schema";

const ChapterList: React.FC<{ chapters: ChapterEntry[] }> = ({ chapters }) => {
	return (
		<ul className="space-y-2 mt-2 pl-4">
			{chapters.map((chapter) => (
				<li key={chapter.id}>
					<Link
						href={`/chapters/${chapter.id}`}
						className="text-lg text-gray-600 hover:text-blue-600 hover:underline transition-colors"
					>
						Chapter {chapter.chapter}: {chapter.title}
					</Link>
				</li>
			))}
		</ul>
	);
};

const TableOfContents: React.FC<{ items: PartEntry[] }> = ({ items }) => {
	if (!items || items.length === 0) {
		return null;
	}
	return (
		<nav className="table-of-contents">
			<h2 className="text-3xl font-bold text-gray-800 border-b pb-4 mb-6">
				Contents
			</h2>
			<div className="space-y-8">
				{items.map((part) => (
					<div key={part.part}>
						<h3 className="text-2xl font-semibold text-gray-700">
							PART {part.part}: {part.title}
						</h3>
						<ChapterList chapters={part.chapters} />
					</div>
				))}
			</div>
		</nav>
	);
};

export default TableOfContents;