import React from "react"
import Entry from "./Entry"
import { ChapterSection } from "@/types/generated.ts/chapter-schema"

const Section: React.FC<{ section: ChapterSection }> = ({ section }) => {
	return (
		<section className="chapter-section mt-6">
			<header>
				{/* Section title */}
				<h3 className="text-3xl font-bold text-gray-900 pb-4 mb-6 border-b border-gray-200">
					{section.title}
				</h3>
			</header>

			{/* Use the "prose" class from Tailwind Typography for beautiful article styling */}
			<div className="prose prose-lg max-w-none">
				{section.introduction &&
					section.introduction.map((p, i) => <p key={i}>{p}</p>)}
			</div>

			{section.entries && section.entries.map((entry) => (
                <Entry key={entry.number} entry={entry} />
			))}

			{/* Recursive call for nested sections */}
			{section.sections &&
				section.sections.map((subSection) => (
					<Section key={subSection.title} section={subSection} />
				))}
		</section>
	);
};

export default Section;
