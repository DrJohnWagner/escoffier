// This is the generic shape our component will expect
export default interface TableOfContentsItemType {
    title: string;
    link: string;
    children?: TableOfContentsItemType[];
}