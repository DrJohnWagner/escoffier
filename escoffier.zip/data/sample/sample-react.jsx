import React from "react";

/**
 * A reusable helper component to render lists that follow the ContentBlock schema.
 * It intelligently handles both simple strings and complex objects with titles.
 * @param {object} props
 * @param {string} props.title - The heading for the section (e.g., "Ingredients").
 * @param {Array} props.items - The array of data to render.
 * @param {boolean} props.isOrdered - If true, renders an ordered list (<ol>) for steps.
 */
function ContentBlockList({ title, items, isOrdered = false }) {
	// If there are no items, don't render the section at all.
	if (!items || items.length === 0) {
		return null;
	}

	const ListTag = isOrdered ? "ol" : "ul";
	const NestedListTag = isOrdered ? "ol" : "ul";

	return (
		<section className={`${title.toLowerCase()}-section`}>
			<h3>{title}</h3>
			<ListTag className={`${title.toLowerCase()}-list`}>
				{items.map((item, index) => {
					// Case 1: The item is a simple string.
					if (typeof item === "string") {
						return <li key={index}>{item}</li>;
					}

					// Case 2: The item is a complex object with a title.
					if (typeof item === "object" && item !== null) {
						const blockTitle = Object.keys(item)[0];
						const blockDetails = item[blockTitle];

						return (
							<li key={index} className="content-block-object">
								<h4 className="content-block-title">{blockTitle}</h4>
								<NestedListTag
									className={isOrdered ? "instruction-steps" : "nested-list"}
								>
									{blockDetails.map((detail, detailIndex) => (
										<li key={detailIndex}>{detail}</li>
									))}
								</NestedListTag>
							</li>
						);
					}

					return null; // Should not happen with valid data
				})}
			</ListTag>
		</section>
	);
}

/**
 * The main component to display a single recipe.
 * @param {object} props
 * @param {object} props.data - The JSON object for the recipe.
 */
function Recipe({ data }) {
	const {
		number,
		title,
		yield: recipeYield,
		introduction,
		ingredients,
		instructions,
		notes,
	} = data;

	return (
		<article id={`recipe-${number}`} className="recipe">
			<header className="recipe-header">
				<h2>
					<span id={`recipe-${number}-number`} className="recipe-number">
						{number}
					</span>
					—
					<span id={`recipe-${number}-title`} className="recipe-title">
						{title}
					</span>
				</h2>
			</header>

			<div id={`recipe-${number}-summary`} className="recipe-summary">
				{recipeYield && (
					<p id={`recipe-${number}-yield`} className="recipe-yield">
						<strong>Yield:</strong> {recipeYield}
					</p>
				)}
				{introduction && (
					<p
						id={`recipe-${number}-introduction`}
						className="recipe-introduction"
					>
						{introduction}
					</p>
				)}
			</div>

			<main className="recipe-body">
				<ContentBlockList title="Ingredients" items={ingredients} />
				<ContentBlockList
					title="Instructions"
					items={instructions}
					isOrdered={true}
				/>
			</main>

			<aside id={`recipe-${number}-notes`} className="recipe-notes">
				<ContentBlockList title="Notes" items={notes} />
			</aside>
		</article>
	);
}

export default Recipe;

// HOW TO USE THIS COMPONENT IN YOUR MAIN APP:
/*
    import Recipe from './Recipe';

    // This would be your JSON data, loaded from a file or an API
    const recipeData = {
    "number": 216,
    "title": "DIRECTIONS FOR SOUP WITH PASTES",
    // ... all the other fields from our JSON example
    };

    function App() {
    return (
    <div>
        <h1>My Digital Cookbook</h1>
        <Recipe data={recipeData} />
    </div>
    );
    }
    */
