import TableOfContentsItemType from "@/types/TableOfContentsItemType";

// Adapter #1: Transforms the Cookbook's Table of Contents
const createChapterTOC = (chapterData): TableOfContentsItemType[] => {
// This function can be recursive to handle nested sections
  function transformSections(sections) {
    return sections.map(section => ({
      title: section.title,
      link: `#${generateSlug(section.title)}`, // Helper to create a URL-friendly anchor
      children: section.sections ? transformSections(section.sections) : [],
    }));
  }
  return transformSections(chapterData.sections);
}

export default createChapterTOC