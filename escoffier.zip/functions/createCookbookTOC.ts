import TableOfContentsItemType from "@/types/TableOfContentsItemType";

// Adapter #1: Transforms the Cookbook's Table of Contents
const createCookbookTOC = (cookbookData): TableOfContentsItemType[] => {
  return cookbookData.contents.map(part => ({
    title: `PART ${part.part}: ${part.title}`,
    link: `#part-${part.part}`, // Or null if it's just a heading
    children: part.chapters.map(chapter => ({
      title: `Chapter ${chapter.chapter}: ${chapter.title}`,
      link: `/chapters/${chapter.id}`,
      children: [], // No deeper nesting
    })),
  }));
}

export default createCookbookTOC